极客学院apk下载地址：
http://124.193.230.157/dd.myapp.com/16891/28F3DE528CE9DAE149E2D39A26BB94CA.apk?mkey=5735c90b910ce983&f=8e5d&c=0&fsname=com.jikexueyuan.geekacademy_4.2.0-4f71632_421.apk&p=.apk
String[] urls={
        "http://img4.duitang.com/uploads/item/201209/03/20120903121445_nx5wk.jpeg",
        "http://i7.qhimg.com/t01755f436ab31acc3e.jpg",
        "http://www.dianziyan668.com/images/mnsg4lteovuxiylom4xgg33n/uploads/item/201203/11/20120311204006_GraP2.jpeg",
        "http://p2.gexing.com/G1/M00/85/40/rBACFFPoibzDeIc6AAC_zw6Zw1Y995_600x.jpg",
        "http://img3.duitang.com/uploads/item/201509/20/20150920214014_dYSRj.jpeg",
        "http://img4.imgtn.bdimg.com/it/u=2141450888,3610011306&fm=11&gp=0.jpg"
    };